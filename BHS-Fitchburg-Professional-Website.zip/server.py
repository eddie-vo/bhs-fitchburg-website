import os, json, time, re, urllib.request, urllib.parse, collections
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
ROOT=Path(__file__).resolve().parent / 'public'
LIMITS=collections.defaultdict(list)
ALLOWED_INTERESTS=['general', 'groups', 'professional', 'medication-management', 'therapy-counseling', 'psychiatric-evaluations', 'tms', 'spravato', 'substance-use-treatment', 'medication-assisted-treatment', 'telehealth', 'veterans-families', 'adhd-parents', 'family-support', 'spanish-language']
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(ROOT),**kwargs)
    def log_message(self,fmt,*args): pass
    def end_headers(self):
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','strict-origin-when-cross-origin')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Content-Security-Policy',"default-src 'self'; img-src 'self' https://images.pexels.com; style-src 'self' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'")
        super().end_headers()
    def reply(self,status,message):
        body=json.dumps({'message':message}).encode(); self.send_response(status); self.send_header('Content-Type','application/json'); self.send_header('Cache-Control','no-store'); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        if self.path.split('?')[0]=='/api/contact': return self.reply(405,'Use the website form or call 978-296-8300.')
        super().do_GET()
    def do_POST(self):
        if self.path!='/api/contact': return self.reply(404,'Not found.')
        origin=self.headers.get('Origin',''); expected=os.getenv('PUBLIC_ORIGIN','').rstrip('/')
        if expected and origin!=expected: return self.reply(403,'Request origin not allowed.')
        if not expected: return self.reply(503,'Online submission is not configured. Your request was not sent. Please call 978-296-8300.')
        try:
            n=int(self.headers.get('Content-Length','0'))
            if not 0<n<=4096: return self.reply(413,'Invalid request size. Please call the office.')
            if self.headers.get('Content-Type','').split(';')[0]!='application/json': return self.reply(415,'Unsupported request format.')
            data=json.loads(self.rfile.read(n))
            if not isinstance(data,dict): raise ValueError()
        except Exception: return self.reply(400,'Please check the form and try again.')
        if data.get('website'): return self.reply(400,'Unable to process this request. Please call the office.')
        now=time.time(); ip=self.client_address[0]; LIMITS[ip]=[t for t in LIMITS[ip] if now-t<3600]
        if len(LIMITS[ip])>=5:return self.reply(429,'Too many requests. Please call 978-296-8300.')
        LIMITS[ip].append(now)
        name=str(data.get('name','')).strip(); phone=str(data.get('phone','')).strip(); email=str(data.get('email','')).strip(); interest=str(data.get('interest','general')); window=str(data.get('time','no-preference'))
        if not 1<=len(name)<=80 or not 7<=len(re.sub(r'\D','',phone))<=15 or len(phone)>30 or len(email)>120 or (email and not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',email)) or data.get('consent') is not True or interest not in ALLOWED_INTERESTS or window not in ['morning','afternoon','no-preference']:
            return self.reply(400,'Please check your name, phone, email, and consent.')
        endpoint=os.getenv('CONTACT_WEBHOOK_URL','')
        if not endpoint.startswith('https://'):return self.reply(503,'Online submission is not configured. Your request was not sent. Please call 978-296-8300.')
        payload={'name':name,'phone':phone,'email':email,'interest':interest,'preferred_time':window,'general_voicemail_allowed':data.get('voicemail') is True,'callback_consent':True,'source':'BHS Fitchburg website'}
        headers={'Content-Type':'application/json'}
        if os.getenv('CONTACT_WEBHOOK_TOKEN'):headers['Authorization']='Bearer '+os.environ['CONTACT_WEBHOOK_TOKEN']
        try:
            request=urllib.request.Request(endpoint,data=json.dumps(payload).encode(),headers=headers,method='POST')
            with urllib.request.urlopen(request,timeout=12) as response:
                if not 200<=response.status<300:raise ValueError()
            return self.reply(200,'Your callback request was received by the configured receiving service. This is not an appointment confirmation. Call the office for time-sensitive questions.')
        except Exception:return self.reply(502,'We could not confirm delivery. Please call 978-296-8300 before trying again to avoid duplicate requests.')
if __name__=='__main__':
    host=os.getenv('HOST','127.0.0.1'); port=int(os.getenv('PORT','8080')); print(f'Preview server: http://{host}:{port}'); ThreadingHTTPServer((host,port),Handler).serve_forever()
