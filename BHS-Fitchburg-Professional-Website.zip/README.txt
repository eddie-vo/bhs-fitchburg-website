BHS FITCHBURG PROFESSIONAL WEBSITE — CONTENT-RICH MULTI-PAGE EDITION

RUN LOCALLY
Python 3.10+; no dependencies required for server.
From this folder: python server.py
Then open http://127.0.0.1:8080
Or open public/index.html directly to review visuals (forms require server).

PUBLIC CONTENT
All page content is English. 20 HTML pages include the homepage, eight individual service pages, four individual group pages, services directory, group directory, About, Patient Information, Referrals, Contact, form privacy notice, and photography credits. See actual HTML file list for exact count.
Original supplied logo used without AI redraw. Responsive desktop/mobile layout, real stock photographs, individual page navigation, accessible native FAQ, click-to-call, interest preselection, form validation and genuine backend delivery states.

PHOTOGRAPHS
Real remote Pexels photographs are linked; not bundled or downloaded. A network connection is required for photos and optional Google Fonts. Credits and source links are on photo-credits.html. Review current licensing before launch and replace with approved branch images when available. Photos are labeled illustrative and not represented as BHS facilities, clinicians, patients or support group participants. Remote assets disclose IP/device connection details; review third-party requests before launch.

FORM STATUS — IMPORTANT
Forms are implemented, but delivery is intentionally DISABLED until configured. No success message is shown when delivery is not configured.
Set these environment variables on the server after review:
PUBLIC_ORIGIN=https://YOUR-ACTUAL-DOMAIN
CONTACT_WEBHOOK_URL=https://YOUR-APPROVED-RECEIVER
CONTACT_WEBHOOK_TOKEN=OPTIONAL-SERVER-SIDE-TOKEN
No credentials are included in browser assets. The receiving endpoint must accept JSON and return a 2xx response only after accepting delivery. It must not return redirects or HTML login responses. The server does not send email itself or retain submissions. It forwards only name, phone, optional email, general interest, preferred callback time, voicemail permission and callback consent. NO free-text medical history field exists.
The receiver and its access, retention, security, auditing, workflow and applicable BAA obligations require approval before use. Contact with a medical practice can itself be sensitive; absence of a health-history field does not establish compliance. This build is not HIPAA certified or represented as HIPAA compliant.
A server-side origin check, payload size limits, validation, security headers, and basic in-memory rate limiting are included. These do not replace a production security review. For multi-instance hosting, use durable shared rate limiting; configure a trusted reverse proxy and avoid IP logging. Add abuse controls through approved vendors only.

DEPLOYMENT
Run server.py behind an HTTPS reverse proxy on a managed Python host or a properly administered server. Use a service manager or container, process restarts, patches, restricted environment secrets, appropriate timeout and connection limits, monitoring without contact payloads, and approved access policies. Static-only hosting can serve public/ but cannot run /api/contact without a separately deployed backend. No live deployment or domain purchase has occurred.
Default bind is localhost; set HOST=0.0.0.0 only behind an appropriate production hosting setup. PORT defaults to 8080.

CONTENT BASIS
https://bhsdab.com/: service list, diagnosis areas, care philosophy and history since 1991.
BHS_Fitchburg_Marketing_Launch_Plan.pptx.pdf: three launch communities, later Spanish-language group, peer-support distinction, 90-minute session concept, local access and referral approach.
Owner contact: 463 Main St, Fitchburg MA 01420; 978-296-8300; Fitchburg@bhsdab.com.
Expanded service copy is original general access-oriented editorial content, not copied clinical protocols or individualized medical advice. Mission paraphrases the main BHS commitment. Local vision is proposed editorial content based on the deck, not a confirmed official corporate statement.

APPROVALS BEFORE LAUNCH
Confirm actual services, credentials, providers, insurance enrollment, age ranges, hours, parking, accessibility, languages, telehealth eligibility, prices, privacy notices and clinical procedures.
Support groups remain marked planned; no invented sessions, fees, partnerships, certifications or outcomes. NAMI-trained facilitator and veterans partnerships are described as proposed, not verified.
Resolve opening dates separately: earlier flyer 10/15/2026 versus deck Nov 1 without a year. No opening date or guaranteed three-day appointment availability is published.
No fake testimonials, staff profiles, ratings or patient stories. Do not introduce analytics, retargeting or participant photos without approved review.
Approve the website privacy notice and publish any formal Notice of Privacy Practices through the appropriate organizational process.

SOURCE PHOTO PAGES
https://www.pexels.com/photo/8560051/
https://www.pexels.com/photo/3958423/
https://www.pexels.com/photo/3958426/
https://www.pexels.com/photo/23496508/
https://www.pexels.com/photo/6255882/
